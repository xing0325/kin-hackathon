# KIN — Current State

## Core loop

Discover → Understand → Context Handshake → Shared Context → Agent Help.

## Verified now

- Two Cardputer-Adv devices complete the real bilateral handshake through Agent_link, BLE relay and FastAPI.
- TiDB Zero has the live schema, three `VECTOR(64)` columns/indexes and a verified vector-query closed loop.
- User Web contains Login, Onboarding, Today, Radar/Match, Ask/Experience, Relationship Memory, Profile/Context Studio, Campfire and Signal.
- Broadcast supports NEED, BUILDING, SOLVED, DISCOVERED and AVAILABLE; matching Signals and relationship commitments feed proactive Today cards.
- Conversation Collector keeps raw conversations local; KIN Bridge produces summary-only candidates, and Context Studio requires explicit approval before publication.
- V0.11 adds signed multi-user sessions, a persistent Agent Inbox, request tracing, metrics, readiness checks and a repeatable two-account/two-device release regression.

## Active implementation

V0.11 release hardening is complete in code: EigenFlux can exchange trusted identities for signed HttpOnly KIN sessions; notifications are owner-scoped and acknowledged; API/worker deployment and operational probes are documented.

## Constraints

- ESP32 remains a Thin Client.
- Raw conversations stay local; only approved Experience Artifacts are published.
- A team forms only after every member confirms their own role.
- Hardware facts require board/BSP/real-device evidence.

## Next release

Run the release stack against the shared TiDB environment, complete one final physical two-Cardputer acceptance pass, then freeze the Hackathon demo candidate. No new product page is required before that acceptance.
