#!/usr/bin/env python3
"""Create KIN's TiDB database and apply the idempotent schema migration."""

from __future__ import annotations

import site
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for packages in (ROOT / "apps/api/.venv/lib").glob("python*/site-packages"):
    site.addsitedir(str(packages))

import certifi
import pymysql

sys.path.insert(0, str(Path(__file__).resolve().parent))
from tidb_keychain import load  # noqa: E402


def main() -> None:
    item = load()
    migration = (ROOT / "infra/migrations/0001_initial_tidb.sql").read_text()
    statements = [part.strip() for part in migration.split(";") if part.strip()]
    connection = pymysql.connect(
        host=item["host"],
        port=int(item["port"]),
        user=item["username"],
        password=item["password"],
        ssl={"ca": certifi.where()},
        connect_timeout=10,
        read_timeout=30,
        write_timeout=30,
        autocommit=True,
    )
    try:
        with connection.cursor() as cursor:
            cursor.execute("CREATE DATABASE IF NOT EXISTS kin")
            cursor.execute("USE kin")
            for statement in statements:
                cursor.execute(statement)
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
        print(f"TIDB_MIGRATION_RESULT: statements={len(statements)} tables={len(tables)}")
    finally:
        connection.close()


if __name__ == "__main__":
    main()
