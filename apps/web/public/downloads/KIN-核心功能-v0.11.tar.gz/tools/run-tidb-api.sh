#!/bin/zsh
set -euo pipefail

ROOT="${0:A:h:h}"
PORT="${1:-8012}"
cd "$ROOT/apps/api"
export DATABASE_URL="$(.venv/bin/python -c 'import sys; sys.path.insert(0, "../../tools"); from tidb_keychain import sqlalchemy_url; print(sqlalchemy_url())')"
exec .venv/bin/uvicorn app.main:app --host 127.0.0.1 --port "$PORT"

