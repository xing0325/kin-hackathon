# KIN Conversation Collector

Chrome / Edge Manifest V3 extension for collecting AI chatbot conversations into a local, portable KIN JSON export.

## Policy

Every discovered session is retained by default. A session is excluded only after the user explicitly checks **Ignore**. Ignore is sticky across later page captures.

Raw conversations stay in `chrome.storage.local`; this version never uploads them. Export includes every non-ignored session.

## Supported web apps

- ChatGPT
- Claude
- Gemini
- 豆包
- DeepSeek

Adapters combine host/path identification with platform-specific message selectors and conservative generic fallbacks. Since chatbot DOMs change, each adapter must be smoke-tested after upstream UI updates.

## Load unpacked

1. Run `npm test && npm run build` in this directory.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Choose **Load unpacked** and select the absolute `dist/` directory.
5. Open a supported chatbot. The current session and visible sidebar sessions are discovered automatically.
6. Use **同步已发现会话** to capture unopened discovered sessions, mark any unwanted sessions as **Ignore**, then export JSON.

## Data boundary

The exported JSON is an ingestion source for a future local KIN Bridge. Experience extraction and cloud upload are deliberately separate approval steps.
