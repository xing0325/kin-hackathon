import { exportEnvelope, mergeConversation } from "./shared/model.mjs";

const STORAGE_KEY = "kinConversations";
let syncQueue = [];
let activeSyncTab = null;
let activeSyncTimer = null;

async function readAll() {
  return (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY] || {};
}

async function writeAll(records) {
  await chrome.storage.local.set({ [STORAGE_KEY]: records });
}

async function upsertMany(items) {
  const records = await readAll();
  for (const item of items.filter(Boolean)) records[item.id] = mergeConversation(records[item.id], item);
  await writeAll(records);
  await updateBadge(records);
  return Object.values(records);
}

async function updateBadge(records = null) {
  const values = Object.values(records || await readAll());
  const kept = values.filter((item) => !item.ignored).length;
  await chrome.action.setBadgeBackgroundColor({ color: "#f77e2d" });
  await chrome.action.setBadgeText({ text: kept ? String(kept) : "" });
}

async function setIgnored(id, ignored) {
  const records = await readAll();
  if (records[id]) {
    records[id].ignored = Boolean(ignored);
    records[id].updatedAt = new Date().toISOString();
    await writeAll(records);
    await updateBadge(records);
  }
  return records[id] || null;
}

async function exportJson() {
  const payload = exportEnvelope(Object.values(await readAll()));
  const url = `data:application/json;charset=utf-8,${encodeURIComponent(JSON.stringify(payload, null, 2))}`;
  await chrome.downloads.download({ url, filename: `KIN-conversations-${new Date().toISOString().slice(0, 10)}.json`, saveAs: true });
  return payload.conversationCount;
}

async function runNextSync() {
  clearTimeout(activeSyncTimer);
  if (activeSyncTab) {
    try { await chrome.tabs.remove(activeSyncTab); } catch {}
    activeSyncTab = null;
  }
  const next = syncQueue.shift();
  if (!next) return;
  const tab = await chrome.tabs.create({ url: next, active: false });
  activeSyncTab = tab.id;
  activeSyncTimer = setTimeout(runNextSync, 15000);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message.type === "CAPTURE_PAGE") {
      const records = await upsertMany([...(message.discovered || []), message.conversation]);
      if (sender.tab?.id === activeSyncTab && message.conversation?.messages?.length) await runNextSync();
      sendResponse({ ok: true, count: records.length });
    } else if (message.type === "LIST_CONVERSATIONS") {
      sendResponse({ ok: true, conversations: Object.values(await readAll()).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)) });
    } else if (message.type === "SET_IGNORED") {
      sendResponse({ ok: true, conversation: await setIgnored(message.id, message.ignored) });
    } else if (message.type === "EXPORT_JSON") {
      sendResponse({ ok: true, count: await exportJson() });
    } else if (message.type === "SYNC_DISCOVERED") {
      const records = Object.values(await readAll());
      syncQueue = records.filter((item) => !item.ignored && item.captureState !== "captured" && item.url).map((item) => item.url);
      const count = syncQueue.length;
      if (!activeSyncTab) await runNextSync();
      sendResponse({ ok: true, count });
    } else if (message.type === "CLEAR_LOCAL") {
      await writeAll({});
      await updateBadge({});
      sendResponse({ ok: true });
    }
  })().catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});

chrome.runtime.onInstalled.addListener(() => updateBadge());
