(async () => {
  const { captureDocument, discoverSessions } = await import(chrome.runtime.getURL("src/adapters/index.mjs"));
  let timer = null;
  let lastSignature = "";

  async function capture() {
    const conversation = captureDocument(document, window.location);
    const discovered = discoverSessions(document, window.location);
    const signature = JSON.stringify([location.href, conversation?.messages?.length, discovered.length, document.title]);
    if (signature === lastSignature) return;
    lastSignature = signature;
    try {
      await chrome.runtime.sendMessage({ type: "CAPTURE_PAGE", conversation, discovered });
    } catch {
      // Extension reloads can invalidate an existing content-script context.
    }
  }

  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(capture, 700);
  }

  new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  window.addEventListener("popstate", schedule);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) schedule(); });
  schedule();
})();
