const list = document.querySelector("#sessions");
const status = document.querySelector("#status");
const template = document.querySelector("#session-template");

async function message(payload) {
  const response = await chrome.runtime.sendMessage(payload);
  if (!response?.ok) throw new Error(response?.error || "Extension request failed");
  return response;
}

function render(conversations) {
  list.replaceChildren();
  const kept = conversations.filter((item) => !item.ignored);
  document.querySelector("#kept-count").textContent = kept.length;
  document.querySelector("#ignored-count").textContent = conversations.length - kept.length;
  document.querySelector("#pending-count").textContent = conversations.filter((item) => item.captureState !== "captured" && !item.ignored).length;
  for (const item of conversations) {
    const row = template.content.firstElementChild.cloneNode(true);
    row.querySelector(".source").textContent = item.source;
    row.querySelector(".title").textContent = item.title;
    row.querySelector(".meta").textContent = item.captureState === "captured" ? `${item.messages.length} messages` : "discovered · pending sync";
    const checkbox = row.querySelector("input");
    checkbox.checked = item.ignored;
    checkbox.addEventListener("change", async () => {
      await message({ type: "SET_IGNORED", id: item.id, ignored: checkbox.checked });
      await load();
    });
    list.append(row);
  }
}

async function load() {
  const response = await message({ type: "LIST_CONVERSATIONS" });
  render(response.conversations);
}

document.querySelector("#export").addEventListener("click", async () => {
  const response = await message({ type: "EXPORT_JSON" });
  status.textContent = `已导出 ${response.count} 个未忽略会话。`;
});

document.querySelector("#sync").addEventListener("click", async () => {
  const response = await message({ type: "SYNC_DISCOVERED" });
  status.textContent = response.count ? `正在后台同步 ${response.count} 个会话…` : "没有待同步会话。";
  setTimeout(load, 1200);
});

load().catch((error) => { status.textContent = error.message; });
