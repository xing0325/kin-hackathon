import test from "node:test";
import assert from "node:assert/strict";
import { dedupeMessages, exportEnvelope, mergeConversation, stableId } from "../src/shared/model.mjs";
import { adapterFor, SUPPORTED_SOURCES } from "../src/adapters/index.mjs";

test("all required chatbot hosts have adapters", () => {
  const cases = {
    "chatgpt.com": "chatgpt",
    "claude.ai": "claude",
    "gemini.google.com": "gemini",
    "www.doubao.com": "doubao",
    "chat.deepseek.com": "deepseek"
  };
  for (const [hostname, source] of Object.entries(cases)) assert.equal(adapterFor({ hostname })?.source, source);
  assert.deepEqual(SUPPORTED_SOURCES.map((item) => item.source), ["chatgpt", "claude", "gemini", "doubao", "deepseek"]);
});

test("new and captured sessions are retained by default", () => {
  const incoming = { id: stableId("doubao", "42"), source: "doubao", externalId: "42", title: "ESP32", messages: [{ role: "user", content: "help" }] };
  const merged = mergeConversation(null, incoming);
  assert.equal(merged.ignored, false);
  assert.equal(exportEnvelope([merged], "2026-08-28T00:00:00.000Z").conversationCount, 1);
});

test("ignore is explicit and sticky across later captures", () => {
  const base = { id: "conv_1", source: "deepseek", ignored: true, messages: [], updatedAt: "x" };
  const recaptured = mergeConversation(base, { id: "conv_1", source: "deepseek", title: "private", messages: [{ role: "assistant", content: "secret" }] });
  assert.equal(recaptured.ignored, true);
  assert.equal(exportEnvelope([recaptured]).conversationCount, 0);
});

test("dedupe removes empty and repeated adjacent messages", () => {
  assert.deepEqual(dedupeMessages([
    { role: "user", content: " hi  " },
    { role: "user", content: "hi" },
    { role: "assistant", content: "\n" }
  ]), [{ role: "user", content: "hi" }]);
});
